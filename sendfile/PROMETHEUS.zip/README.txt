告警源导入指引
统一告警中心版本：2.2或以上
来源：温氏，武隆
提供者：卢政洪, 毕助逵, 王良, 肖潇

接入步骤：

1. 导入告警源

2. 初始化告警配置

   到插件管理页面，确认导入的告警源状态，根据告警源状态（执行下方对应的操作）

   2.1 已上传：点击对应告警源记录的调试按钮，进入配置页面

   2.1.1 确认告警源配置信息无误后，点击最下方调试按钮进行调试

   2.1.2 拉取类型告警源：填入参数配置（如无可忽略），点击校验插件状态

          推送类型告警源：根据测试指引进行操作后，点击获取校验结果
          注意： prometheus告警源还需要以下额外步骤：
          1) 通过验证
                修改 alertmanager 模块的配置文件，通过 webhook 方式通知告警中心，编辑告警的配置文件， 新增 webhook_configs:及以下内容。 receivers:
                - name: 'alarmcenter'
                webhook_configs:
                - url: ' http://{uac_host:uac_port}/alarm/collect/event/verification/{prometheus_alarmsource_id}/'
                send_resolved: true
                重新启动alertmanager模块，并加载该配置文件。
                其中{uac_host:uac_port}为告警中心saas地址，{prometheus_alarmsource_id}为上传后的prometheus告警源调试页面的id参数
           2) 完成下方2.1.3和2.1.4后，执行：
                 修改 alertmanager 模块的配置文件，通过 webhook 方式通知告警中心，编辑告警的配置文件， 新增 webhook_configs:及以下内容。 receivers:
                - name: 'alarmcenter'
                webhook_configs:
                - url: ' http://{uac_host:uac_port}/alarm/collect/event/common/{prometheus_alarmsource_id}/'
                send_resolved: true
                重新启动alertmanager模块，并加载该配置文件。
           3) 完成

   2.1.3 点击页面最下方的校验完成。

   2.1.4 返回插件管理页面上线对应告警源

   2.2 已验证：点击对应告警源后的上线按钮

   2.3 已上线：无需操作

3. 到告警源接入页面，点击需要启动的告警源图标，检查告警源配置（若无可忽略），确认无误后返回。

4. 启用对应告警源


注意：1.若告警源需要额外的脚本、配置等文件，在压缩包下的创建extra_folder文件夹，复制额外文件到该目录下
     2.根据实际情况更新上方的接入步骤，详细描述如何接入对应告警源及对应脚本/配置使用方式。
